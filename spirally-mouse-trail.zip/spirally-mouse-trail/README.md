# Spirally mouse trail

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicksheffield/pen/GgdNop](https://codepen.io/nicksheffield/pen/GgdNop).

Watch them try to keep up